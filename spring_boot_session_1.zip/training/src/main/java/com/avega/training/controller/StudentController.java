package com.avega.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.avega.training.dto.ResponseDto;
import com.avega.training.dto.StudentDto;
import com.avega.training.service.StudentService;

@RestController
@RequestMapping("api")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/student/{studentId}")
	public ResponseEntity<StudentDto> getStudentDetailsById(@PathVariable("studentId") String studentId) {
		return ResponseEntity.ok(studentService.getStudentDetailsById(studentId));
	}

	@PostMapping("/student")
	public ResponseEntity<ResponseDto> saveStudentDetails(@RequestBody StudentDto dto) {
		return ResponseEntity.ok(studentService.saveStudentDetails(dto));
	}

	@GetMapping("/student")
	public ResponseEntity<List<StudentDto>> getAllStudentDetails() {
		return ResponseEntity.ok(studentService.getAllStudentDetails());
	}

	@DeleteMapping("/student")
	public ResponseEntity<ResponseDto> deleteStudentById(@RequestParam("studentId") String studentId) {
		return ResponseEntity.ok(studentService.deleteStudentById(studentId));
	}

}
