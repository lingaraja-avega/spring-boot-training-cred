package com.avega.training.dto;

public class StudentDto {

	private String studentId;

	private String studentName;

	private String branch;

	private String phoneNumber;

	private int age;

	public StudentDto() {

	}

	public StudentDto(String studentId, String studentName, String branch, String phoneNumber, int age) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.branch = branch;
		this.phoneNumber = phoneNumber;
		this.age = age;
	}

	public String getStudentId() {
		return studentId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

}
