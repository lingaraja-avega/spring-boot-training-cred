package com.avega.training.entity;

import java.time.LocalDate;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "student")
@Data
public class StudentEntity {

	@Id
	@Column(name = "student_id")
	@UuidGenerator
	private String studentId;

	@Column(name = "student_name")
	private String studentName;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "branch")
	private BranchEntity branch;

	@Column(name = "mobile_number")
	private String phoneNumber;

	private int age;

	@Column(name = "date_of_birth")
	private LocalDate dateOfBirth;

}
