package com.avega.training.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.avega.training.dto.BranchDto;
import com.avega.training.dto.ResponseDto;
import com.avega.training.service.BranchService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class BranchController {

	private final BranchService branchService;

	@GetMapping("/branch/{branchId}")
	public ResponseEntity<BranchDto> getBranchDetailsById(@PathVariable("branchId") String branchId) {
		return ResponseEntity.ok(branchService.getBranchDetailsById(branchId));
	}

	@PostMapping("/branch")
	public ResponseEntity<ResponseDto> saveBranch(@RequestBody BranchDto dto) {

		return ResponseEntity.ok(branchService.saveBranchDetails(dto));

	}

	@GetMapping("/branch")
	public ResponseEntity<List<BranchDto>> getAllBranchDetails() {
		return ResponseEntity.ok(branchService.getAllBranchDetails());
	}

	@DeleteMapping("/branch")
	public ResponseEntity<ResponseDto> deleteBranchById(@RequestParam("branchId") String branchId) {
		return ResponseEntity.ok(branchService.deleteBranchById(branchId));
	}

}
