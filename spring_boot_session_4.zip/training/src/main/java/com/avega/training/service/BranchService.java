package com.avega.training.service;

import java.util.List;

import com.avega.training.dto.BranchDto;
import com.avega.training.dto.ResponseDto;

public interface BranchService {

	BranchDto getBranchDetailsById(String branchId);

	List<BranchDto> getAllBranchDetails();

	ResponseDto saveBranchDetails(BranchDto dto);

	ResponseDto deleteBranchById(String branchId);

}
