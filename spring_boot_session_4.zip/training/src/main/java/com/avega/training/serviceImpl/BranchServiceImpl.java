package com.avega.training.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.training.dao.BranchRepository;
import com.avega.training.dto.BranchDto;
import com.avega.training.dto.ResponseDto;
import com.avega.training.entity.BranchEntity;
import com.avega.training.service.BranchService;

import jakarta.persistence.NamedStoredProcedureQuery;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BranchServiceImpl implements BranchService {

	private final BranchRepository branchRepository;

	@Override
	public ResponseDto saveBranchDetails(BranchDto dto) {

		ResponseDto response = new ResponseDto();

		try {

			BranchEntity branch = new BranchEntity();
			if (dto.getBranchId() != null) {

				Optional<BranchEntity> branchOpt = branchRepository.findById(dto.getBranchId());
				if (!branchOpt.isEmpty()) {
					branch = branchOpt.get();
//
					branch.setBranchId(dto.getBranchId());
					branch.setBranchName(dto.getBranchName());

				}
			} else {
				branch.setBranchName(dto.getBranchName());

			}

			branchRepository.save(branch);
			response.setMessage("SUCCESS");

		} catch (Exception e) {
			response.setMessage("FAILURE");
			throw e;
		}

		return response;
	}

	@Override
	public List<BranchDto> getAllBranchDetails() {

		try {
			List<BranchEntity> branchList = branchRepository.findAll();

			List<BranchDto> dtoList = new ArrayList<BranchDto>();

			branchList.forEach(details -> {

				BranchDto dto = new BranchDto();
				dto.setBranchId(details.getBranchId());
				dto.setBranchName(details.getBranchName());

				dtoList.add(dto);

			});

			return dtoList;

		} catch (Exception e) {
			throw e;
		}

	}

	@Override
	public BranchDto getBranchDetailsById(String branchId) {

		BranchDto dto = new BranchDto();
		Optional<BranchEntity> branchOpt = branchRepository.findById(branchId);
		if (!branchOpt.isEmpty()) {
			BranchEntity branch = branchOpt.get();
			dto.setBranchId(branch.getBranchId());
			dto.setBranchName(branch.getBranchName());

		}
		return dto;
	}

	@Override
	public ResponseDto deleteBranchById(String branchId) {
		ResponseDto response = new ResponseDto();

		try {

			if (branchRepository.existsById(branchId)) {
				branchRepository.deleteById(branchId);
				response.setMessage("DELETE SUCCESFULLY");
				return response;
			}

			response.setMessage("BRANCH ID NOT FOUND");

		} catch (Exception e) {
			response.setMessage("FAILED");
			throw e;
		}

		return response;
	}

}
