package com.avega.training.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "branch")
@Data
public class BranchEntity {

	@Id
	@UuidGenerator
	@Column(name = "branch_id")
	private String branchId;

	@Column(name = "branch_name")
	private String branchName;
	
	
	
}
