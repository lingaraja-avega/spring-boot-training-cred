package com.avega.training.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avega.training.dao.StudentRepository;
import com.avega.training.dto.ResponseDto;
import com.avega.training.dto.StudentDto;
import com.avega.training.entity.StudentEntity;
import com.avega.training.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public ResponseDto saveStudentDetails(StudentDto dto) {

		ResponseDto response = new ResponseDto();

		try {

			StudentEntity student = new StudentEntity();
			if (dto.getStudentId() != null) {

				Optional<StudentEntity> studentOpt = studentRepository.findById(dto.getStudentId());
				if (!studentOpt.isEmpty()) {
					student = studentOpt.get();
					student.setStudentName(dto.getStudentName());
					student.setPhoneNumber(dto.getPhoneNumber());
					student.setAge(dto.getAge());
					student.setBranch(dto.getBranch());
				}
			} else {

				student.setStudentName(dto.getStudentName());
				student.setPhoneNumber(dto.getPhoneNumber());
				student.setAge(dto.getAge());
				student.setBranch(dto.getBranch());

			}

			studentRepository.save(student);
			response.setMessage("SUCCESS");

		} catch (Exception e) {
			response.setMessage("FAILURE");
			throw e;
		}

		return response;
	}

	@Override
	public List<StudentDto> getAllStudentDetails() {

		List<StudentEntity> detailss = studentRepository.getDetailss("IT", 22);
		detailss.forEach(row -> System.out.println(row.getStudentName()));

		try {
			List<StudentEntity> studentList = studentRepository.findAll();

			List<StudentDto> dtoList = new ArrayList<StudentDto>();

			studentList.forEach(details -> {

				StudentDto dto = new StudentDto();
				dto.setStudentId(details.getStudentId());
				dto.setStudentName(details.getStudentName());
				dto.setPhoneNumber(details.getPhoneNumber());
				dto.setAge(details.getAge());
				dto.setBranch(details.getBranch());
				dtoList.add(dto);

			});

			return dtoList;

		} catch (Exception e) {
			throw e;
		}

	}

	@Override
	public StudentDto getStudentDetailsById(String studentId) {

		StudentDto dto = new StudentDto();
		Optional<StudentEntity> studentOpt = studentRepository.findById(studentId);
		if (!studentOpt.isEmpty()) {

			StudentEntity student = studentOpt.get();

			dto.setStudentId(student.getStudentId());
			dto.setStudentName(student.getStudentName());
			dto.setPhoneNumber(student.getPhoneNumber());
			dto.setAge(student.getAge());
			dto.setBranch(student.getBranch());

		}
		return dto;
	}

	@Override
	public ResponseDto deleteStudentById(String studentId) {
		ResponseDto response = new ResponseDto();

		try {

			if (studentRepository.existsById(studentId)) {
				studentRepository.deleteById(studentId);
				response.setMessage("DELETE SUCCESFULLY");
				return response;
			}

			response.setMessage("STUDENT ID NOT FOUND");

		} catch (Exception e) {
			response.setMessage("FAILED");
			throw e;
		}

		return response;
	}

}
