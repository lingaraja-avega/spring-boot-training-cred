package com.avega.training.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avega.training.entity.StudentEntity;

@Repository
public interface StudentRepository extends JpaRepository<StudentEntity, String> {

	List<StudentEntity> findAllByBranchAndAge(String branch, int age);

	@Query(nativeQuery = true, value = "SELECT * FROM student WHERE branch = :branch AND age = :age")
	List<StudentEntity> getDetails(@Param("branch") String branch, @Param("age") int age);

	@Query(value = "SELECT se FROM StudentEntity se WHERE se.branch = :branch AND se.age = :age")
	List<StudentEntity> getDetailss(@Param("branch") String branch, @Param("age") int age);

}
