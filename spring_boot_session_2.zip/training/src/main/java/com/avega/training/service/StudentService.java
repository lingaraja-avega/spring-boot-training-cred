package com.avega.training.service;

import java.util.List;

import com.avega.training.dto.ResponseDto;
import com.avega.training.dto.StudentDto;

public interface StudentService {

	StudentDto getStudentDetailsById(String studentId);

	List<StudentDto> getAllStudentDetails();

	ResponseDto saveStudentDetails(StudentDto dto);
		
	ResponseDto deleteStudentById(String studentId);

}
