package com.avega.training.entity;

import java.time.LocalDate;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "student")
@Data
public class StudentEntity {

	@Id
	@Column(name = "student_id")
	@UuidGenerator
	private String studentId;

	@Column(name = "student_name")
	private String studentName;

	private String branch;

	@Column(name = "mobile_number")
	private String phoneNumber;

	private int age;

	@Column(name = "date_of_birth")
	private LocalDate dateOfBirth;

}
