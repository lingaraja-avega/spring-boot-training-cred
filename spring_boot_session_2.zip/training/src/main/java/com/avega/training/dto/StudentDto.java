package com.avega.training.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//@Setter
//@Getter
//@ToString
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentDto {

	private String studentId;

	private String studentName;

	private String branch;

	private String phoneNumber;

	private int age;

}
